"""
Homework  : Similarity measures on sets
Course    : Data Mining (636-0018-00L)

Compute all pairwise shortest path kernel of graphs within and between groups.
"""
# Author: Xiao He <xiao.he@bsse.ethz.ch>
# Author: Bastian Rieck <bastian.rieck@bsse.ethz.ch>

import os
import sys
import argparse
import numpy as np
import scipy.io
from shortest_path_kernel import floyd_warshall
from shortest_path_kernel import sp_kernel

# ------------------------------------------------------------------------------
# Main program
# ------------------------------------------------------------------------------

# Set up the parsing of command-line arguments
parser = argparse.ArgumentParser(
    description="Compute similarity functions on graphs")
parser.add_argument("--datadir", required=True,
                    help="Path to input directory containing the MUTAG.mat")
parser.add_argument("--outdir", required=True,
                    help="Path to the output directory where graphs_output.txt will be created")
args = parser.parse_args()

# Set the paths
data_dir = args.datadir
out_dir = args.outdir

# Create the output directory if it does not exist
if not os.path.exists(args.outdir):
    os.makedirs(args.outdir)

# Read the file
mat = scipy.io.loadmat("{}/{}".format(args.datadir, 'MUTAG.mat'))
label = np.reshape(mat['lmutag'], (len(mat['lmutag'], )))
adj = np.reshape(mat['MUTAG']['am'], (len(label),))

# Create the output file
try:
    file_name = "{}/graphs_output.txt".format(args.outdir)
    f_out = open(file_name, 'w')
except IOError:
    print("Output file {} cannot be created".format(file_name))
    sys.exit(1)

# Precompute matrix S for each graph G. No need to repeat the
# calculation each time the kernel function is being invoked!
sp = np.asarray([floyd_warshall(A) for A in adj], dtype=object)

cdict = {}
cdict['mutagenic'] = 1
cdict['non-mutagenic'] = -1
lst_group = ['mutagenic', 'non-mutagenic']

# Iterate through all combinations of pairs
for idx_g1 in range(len(lst_group)):
    for idx_g2 in range(idx_g1, len(lst_group)):
        # Get the group data
        group1 = sp[label == cdict[lst_group[idx_g1]]]
        group2 = sp[label == cdict[lst_group[idx_g2]]]

        # Get average similarity
        count = 0
        vec_sim = 0.0
        for x in group1:
            for y in group2:
                if idx_g1 == idx_g2 and np.array_equal(x, y):
                    continue
                vec_sim += sp_kernel(x, y)
                count += 1
        vec_sim /= count

        # Save the output
        f_out.write(
            "{}:{}\t{:.2f}\n".format(lst_group[idx_g1], lst_group[idx_g2],
                                      vec_sim))

f_out.close()

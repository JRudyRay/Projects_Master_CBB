"""Solution for the shortest-path kernel."""

from collections import Counter

import numpy as np


def floyd_warshall(A):
    """Implement the Floyd--Warshall on an adjacency matrix A.

    Parameters
    ----------
    A : `np.array` of shape (n, n)
        Adjacency matrix of an input graph. If A[i, j] is `1`, an edge
        connects nodes `i` and `j`.

    Returns
    -------
    An `np.array` of shape (n, n), corresponding to the shortest-path
    matrix obtained from A.
    """
    # This function modifies A in-place. This is okay for this homework,
    # but there are use cases where this can wreak havoc. You have been
    # warned!
    N = A.shape[0]
    A[A == 0] = 255  # Beware: this would fail in graphs with diameter > 255!
    np.fill_diagonal(A, 0)
    for k in range(N):
        for i in range(N):
            for j in range(N):
                # Prevent overflow; we must ensure that we do not go
                # above 255 when adjusting the values here.
                if ((A[i][k] < 255) and (A[k][j] < 255)
                        and (A[i][j] > A[i][k] + A[k][j])):
                    A[i][j] = A[i][k] + A[k][j]
    return A


def sp_kernel(S1, S2):
    """Calculate shortest-path kernel from two shortest-path matrices.

    Parameters
    ----------
    S1: `np.array` of shape (n, n)
        Shortest-path matrix of the first input graph.

    S2: `np.array` of shape (m, m)
        Shortest-path matrix of the second input graph.

    Returns
    -------
    A single `float`, corresponding to the kernel value of the two
    shortest-path matrices
    """
    counter_1 = Counter(S1[np.triu_indices(S1.shape[0], k=1)].tolist())
    counter_2 = Counter(S2[np.triu_indices(S2.shape[0], k=1)].tolist())

    match = 0
    for i in counter_1:
        if (i != 0) and (i != 255) and (i in counter_2):
            match += counter_1[i] * counter_2[i]
    return match

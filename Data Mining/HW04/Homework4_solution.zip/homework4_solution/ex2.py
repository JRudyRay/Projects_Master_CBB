#!/usr/bin/env python3

'''
Solution to Homework 4: Logistic Regression and Decision Trees, 
Part 2: Decision Trees

Authors: Anja Gumpinger, Bastian Rieck
'''

import numpy as np
import sklearn.datasets

from sklearn.metrics import accuracy_score
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeClassifier


def split_data(X, y, attribute_index, theta):
    '''
    Split data according to attribute_index (feature) and theta (threshold).
    
    :param X: data matrix
    :param y: label vector
    :param attribute_index: feature (i.e. variable) index
    :param theta: threshold
    
    :return: data/class split according to the attribute, in terms of
    tuples of the form X1, y1, X2, y2.
    '''
    
    # Get the indices of the samples belonging to either one of the
    # splits.
    split_1 = X[:, attribute_index] < theta
    split_2 = X[:, attribute_index] >= theta

    # Perform the split for both the labels and the data matrices.
    X1, y1 = X[split_1, :], y[split_1]
    X2, y2 = X[split_2, :], y[split_2]
    
    return X1, y1, X2, y2


def compute_entropy(probabilities):
    '''
    Computes the entropy of a vector of probabilities. 

    :param probabilities: sequence of probabilities
    :return: entropy
    '''

    # Remove all zeros because they will cause problems in the logarithm
    # calculation.
    probabilities = np.asarray(probabilities)
    probabilities = probabilities[probabilities > 0]

    # Entropy formula from the course. Note that we use `np.log2` to use
    # a logarithm with basis 2.
    entropy = -np.sum(probabilities * np.log2(probabilities))
    return entropy


def compute_information_content(y):
    '''
    Computes information content of a sequence of labels.

    :param y: sequence of labels
    :return: information content
    '''
    
    # If the number of samples in the current split is 0, so is the
    # entropy.
    num_samples = len(y)
    if num_samples == 0:
        return 0

    # Get proportions of class labels in y. These define our
    # probabilities later on.
    proportions = [len(y[y == label]) / num_samples for label in set(y)]

    # Finally, calculate the entropy to obtain the information content.
    information_content = compute_entropy(proportions)
    return information_content


def compute_information_a(X, y, attribute_index, theta):
    '''
    Compute conditional information content Info_A(D).

    :param X: data matrix
    :param y: label vector
    :param attribute_index: feature (i.e. variable) index
    :param theta: threshold

    :return: Conditional information content Info_A(D).
    '''

    # Perform the split according to the threshold and determine the
    # number of samples in each split.
    X1, y1, X2, y2 = split_data(X, y, attribute_index, theta)
    size_1 = len(y1)
    size_2 = len(y2)
    size_total = len(y)

    # Calculate the weights |D_j| / |D|, i.e. the proportions
    weight_1 = size_1 / size_total
    weight_2 = size_2 / size_total

    # Compute the entropies of each split.
    entropy_1 = compute_information_content(y1)
    entropy_2 = compute_information_content(y2)

    # Finally, make this into a weighted sum.
    return weight_1 * entropy_1 + weight_2 * entropy_2
    

def compute_information_gain(X, y, attribute_index, theta):
    '''
    Compute information gain gain(A) = Info(D) - Info_A(D).

    :param X: data matrix
    :param y: label vector
    :param attribute_index: feature (i.e. variable) index
    :param theta: threshold

    :return: Information gain gain(A)
    '''
    
    info_d = compute_information_content(y)
    info_a_d = compute_information_a(X, y, attribute_index, theta)

    return info_d - info_a_d


def output_gain_from_split(X, y, attribute_index, theta):
    '''
    Show information gain on `stdout`.

    :param X: Data matrix
    :param y: Labels
    :param attribute_index: feature (i.e. variable) index
    :param theta: threshold
    '''

    gain_a = compute_information_gain(X, y, attribute_index, theta)

    print("Split ({0:s} < {1:.1f}): information gain = {2:.2f}.".format(
        iris.feature_names[attribute_index].ljust(17),
        theta,
        gain_a)
    )


if __name__ == '__main__':

    iris = sklearn.datasets.load_iris()
    X = iris.data
    y = iris.target

    feature_names = iris.feature_names
    num_features = len(set(feature_names))

    theta_vec = np.array([5.5, 3.0, 2.0, 1.0])
    gain_feat = np.zeros(num_features)

    print('Exercise 2.b')
    print('------------')

    for i in range(num_features):
        gain_feat[i] = compute_information_gain(X, y, i, theta_vec[i])
        output_gain_from_split(X, y, i, theta_vec[i])

    print('')

    print('Exercise 2.c')
    print('------------')

    # Indices of the maximum information gain
    max_gain_idx = np.where(gain_feat == np.max(gain_feat))[0]

    for max_gain in max_gain_idx:
        print(
            'I would select ({0} < {1}) as a split, because it has '
            'the maximum information gain {2:.2f}'.
                format(iris.feature_names[max_gain], theta_vec[max_gain],
                       gain_feat[max_gain])
        )

    print('')

    ####################################################################
    # Exercise 2.d
    ####################################################################

    # Do _not_ remove this line because you will get different splits
    # which make your results different from the expected ones...
    np.random.seed(42)


    # Let's set up a classifier and a $k$-fold cross validation. In
    # practice, the number of splits for CV is something that needs
    # to be given much thought. Common values are 5 or 10.
    clf = DecisionTreeClassifier()
    cv = KFold(n_splits=5, shuffle=True)

    # This performs the cross-validation for us, always reporting the
    # accuracy on every fold. Note: You can of course also implement each
    # fold as shown below (line 225 and following) and calculate the accuracy using
    # sklearn.metrics.accuracy_score.
    scores = cross_val_score(clf, X, y, scoring='accuracy', cv=cv)

    print('Accuracy score using cross-validation')
    print('-------------------------------------\n')

    print('{:.2f} +- {:.2f}'.format(np.mean(scores) * 100, np.std(scores) * 100))
    print('')

    # Report feature importances over the cross-validation. It's
    # possible to do this in a nicer fashion, but we just print
    # everything.

    print('Feature importances for _original_ data set')
    print('-------------------------------------------\n')

    importance = np.zeros((5,num_features))
    split = 0
    for train_index, test_index in cv.split(X, y):
        clf = DecisionTreeClassifier()

        X_train, y_train = X[train_index], y[train_index]
        X_test, y_test = X[test_index], y[test_index]

        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)

        # Print out feature importances and the accuracy for the given
        # fold.
        #
        # This should (roughly) match the scores obtained before. Some
        # deviations are possible because we have not reset the RNG.
        print('-', clf.feature_importances_, '({:.2f})'.format(
                accuracy_score(y_test, y_pred)
            )
        )
        importance[split,:]=clf.feature_importances_
        split += 1

    print('')
    print('For the original data, the two most important features are:')


    print(iris.feature_names[np.argsort(importance.mean(axis = 0))[-2]])
    print('and')
    print(iris.feature_names[np.argsort(importance.mean(axis=0))[-1]])


    # Reduce the data set to two classes and see what we get.

    X = X[y != 2]
    y = y[y != 2]

    print('Feature importances for _reduced_ data set')
    print('------------------------------------------\n')

    for train_index, test_index in cv.split(X, y):
        clf = DecisionTreeClassifier()

        X_train, y_train = X[train_index], y[train_index]
        X_test, y_test = X[test_index], y[test_index]

        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)

        print('-', clf.feature_importances_, '({:.2f})'.format(
                accuracy_score(y_test, y_pred)
            )
        )

        sklearn.tree.export_graphviz(clf, '/tmp/tree.dot')

    # In the output, you should see that only a *single* attribute was
    # used to perform the classification.
    #
    # Furthermore, the perfect accuracy of each split shows that the
    # classes can be perfectly separated. Since only a single attribute
    # was used, the two-class data set is *linearly separable*.

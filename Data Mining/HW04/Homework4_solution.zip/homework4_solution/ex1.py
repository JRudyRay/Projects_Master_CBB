'''
Solution for Homework 4: Logistic Regression and Decision Trees
Part 1: Logistic Regression

Authors: Anja Gumpinger, Dean Bodenham, Bastian Rieck
'''

#!/usr/bin/env python3

import pandas as pd
import numpy as np

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import StandardScaler


def compute_metrics(y_true, y_pred):
    '''
    Computes several quality metrics of the predicted labels and prints
    them to `stdout`.

    :param y_true: true class labels
    :param y_pred: predicted class labels
    '''

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()

    print('Exercise 1.a')
    print('------------\n')
    print('TP: {0:d}'.format(tp))
    print('FP: {0:d}'.format(fp))
    print('TN: {0:d}'.format(tn))
    print('FN: {0:d}'.format(fn))
    print('Accuracy: {0:.3f}'.format(accuracy_score(y_true, y_pred)))
    print('')


if __name__ == "__main__":

    # train and test filenames.
    fileTrain = "data/diabetes_train.csv"
    fileTest  = "data/diabetes_test.csv"

    # read training data from file into pandas data frame.
    df_train = pd.read_csv(fileTrain)

    # strip data from pandas data frame into numpy array.
    # Note: this does not return a matrix, but rather an ARRAY.
    X_train = df_train.iloc[:, 0:7].values

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)

    # strip labels from pandas data frame into numpy array.
    y_train = df_train.iloc[:, 7].values

    # read and parse test data into arrays.
    df_test = pd.read_csv(fileTest)
    X_test = df_test.iloc[:, 0:7].values
    y_test = df_test.iloc[:, 7].values
    X_test = scaler.transform(X_test)

    # built logistic regression model.
    clf = LogisticRegression(C=1)

    # fit and predict.
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)

    # Show the metrics on the test data set in order to judge the
    # performance of the classifier.
    compute_metrics(y_test, y_pred)

    print('Exercise 1.b')
    print('------------\n')

    print('For the diabetes dataset I would choose Logistic Regression, '
          'because it has a higher accuracy.')

    print('Exercise 1.c')
    print('------------\n')

    print('For another dataset, I would choose Logistic Regression, because it '
          'is slightly more general than LDA, which, in our formulation, '
          'relies on the assumption of Gaussianity.')

    print('Exercise 1.d')
    print('------------\n')
    coefs_and_names = list(zip(clf.coef_.ravel(), scaler.var_.ravel(), df_train.columns.tolist()))
    for coef, var, name in sorted(coefs_and_names, key=lambda x: -abs(x[0])):
        print('{:+.2f} (sdev = {:+.2f}): {} [{:+.2f}]'.format(coef, np.sqrt(var), name, np.exp(coef / np.sqrt(var))))

    print('''
The coefficient for npreg is 0.33. An increase in this variable by one
unit, i.e. by one pregnancy, increases the odds of becoming diabetic by
approximately 10% in this scenario. This is calculating as the exponential
function of the ratio of the coefficient (for npreg this is 0.33) 
and the standard deviation (here 3.36).
''')

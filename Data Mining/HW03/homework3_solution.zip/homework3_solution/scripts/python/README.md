# KNN

Execute the script as follows:

    python3 knn.py --traindir ../../data/part1/train --testdir ../../data/part1/test --outdir /tmp --mink 1 --maxk 10

The output `output_knn.txt` will be created in `/tmp`.

# Naive Bayes

Execute the script as follows:

    python3 naive_bayes_summarize_data.py --traindir ../../data/part2/train --outdir /tmp

The output `output_summary_class_2.txt` and `output_summary_class_4.txt`
will be created in `/tmp`.
